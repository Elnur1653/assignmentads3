import java.util.Iterator;
import java.util.Stack;

public class BST<K extends Comparable<K>, V> implements Iterable<BST<K, V>.Node> {

    public class Node {
        private K key;
        private V value;
        private Node left, right;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }

    private Node root;
    private int size = 0;

    // ✅ Вставка (put)
    public void put(K key, V value) {
        root = put(root, key, value);
    }

    private Node put(Node current, K key, V value) {
        if (current == null) {
            size++;
            return new Node(key, value);
        }

        int cmp = key.compareTo(current.key);

        if (cmp < 0) {
            current.left = put(current.left, key, value);
        } else if (cmp > 0) {
            current.right = put(current.right, key, value);
        } else {
            current.value = value; // если ключ уже есть — просто обновляем значение
        }

        return current;
    }

    // ✅ Получение (get)
    public V get(K key) {
        Node current = root;
        while (current != null) {
            int cmp = key.compareTo(current.key);
            if (cmp < 0) current = current.left;
            else if (cmp > 0) current = current.right;
            else return current.value;
        }
        return null;
    }

    // ✅ Размер дерева
    public int size() {
        return size;
    }

    // ✅ Итератор (in-order traversal)
    @Override
    public Iterator<Node> iterator() {
        return new Iterator<>() {
            private Stack<Node> stack = new Stack<>();
            private Node current = root;

            {
                // инициализация — идём в самый левый узел
                while (current != null) {
                    stack.push(current);
                    current = current.left;
                }
            }

            @Override
            public boolean hasNext() {
                return !stack.isEmpty();
            }

            @Override
            public Node next() {
                Node node = stack.pop();
                Node temp = node.right;
                while (temp != null) {
                    stack.push(temp);
                    temp = temp.left;
                }
                return node;
            }
        };

    }
    // ✅ Удаление по ключу
    public void delete(K key) {
        root = delete(root, key);
    }

    private Node delete(Node current, K key) {
        if (current == null) return null;

        int cmp = key.compareTo(current.key);

        if (cmp < 0) {
            current.left = delete(current.left, key);
        } else if (cmp > 0) {
            current.right = delete(current.right, key);
        } else {
            // Ключ найден
            if (current.left == null) {
                size--;
                return current.right;
            }
            if (current.right == null) {
                size--;
                return current.left;
            }

            // Узел с двумя детьми
            Node temp = findMin(current.right);
            current.key = temp.key;
            current.value = temp.value;
            current.right = delete(current.right, temp.key);
        }
        return current;
    }

    // Найти минимальный узел в дереве
    private Node findMin(Node node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

}
