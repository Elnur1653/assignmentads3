public class MyTestingClass {
    private String name;
    private int id;

    public MyTestingClass(String name, int id) {
        this.name = name;
        this.id = id;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MyTestingClass)) return false;
        MyTestingClass that = (MyTestingClass) o;
        return id == that.id && name.equals(that.name);
    }


    @Override
    public int hashCode() {
        int hash = 17;
        hash = 31 * hash + id;
        for (char c : name.toCharArray()) {
            hash = 31 * hash + c;
        }
        return hash;
    }

    @Override
    public String toString() {
        return "MyTestingClass{" + name + ", " + id + '}';
    }
}
