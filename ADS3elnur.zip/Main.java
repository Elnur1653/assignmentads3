public class Main {
    public static void main(String[] args) {
        BST<Integer, String> bst = new BST<>();

        bst.put(5, "Five");
        bst.put(3, "Three");
        bst.put(7, "Seven");
        bst.put(2, "Two");
        bst.put(4, "Four");

        System.out.println("Before deletion:");
        for (BST<Integer, String>.Node node : bst) {
            System.out.println("Key: " + node.getKey() + ", Value: " + node.getValue());
        }

        System.out.println("\nDeleting key 3...");
        bst.delete(3);

        System.out.println("\nAfter deletion:");
        for (BST<Integer, String>.Node node : bst) {
            System.out.println("Key: " + node.getKey() + ", Value: " + node.getValue());
        }

        System.out.println("\nBST Size: " + bst.size());
    }
}

